# Battery Saves

* Fix filename underscore bit
* optional Directory creation on ROM load
* autosave timing, at interval n, at exit when tab closes or new ROM is loaded to ensure no data loss
* ensure ROM load not possible prior to initial sync
