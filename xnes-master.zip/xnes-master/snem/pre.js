var Module = {
	'postRun': function() { 
	   alert("ttt");
	   js_main()	   	
	}
      };
